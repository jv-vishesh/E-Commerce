import 'package:ecommerceapp/Firebase%20Services/firebaseservices.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';

import 'log_in_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   actions: [
      //     PopupMenuButton(itemBuilder: (context)=>[PopupMenuItem(onTap: (){
      //       FirebaseAuth.instance.signOut();
      //       FirebaseServices().googleSignOut();
      //       Navigator.pop(context);
      //     },child: Text("Log Out"))])
      //   ],
      // ),
      body: Center(
        child: Column(
          children: [
            Stack(
              alignment: AlignmentDirectional.centerStart,
              children: [
                Container(
                  height: 409,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                        image: NetworkImage(
                          "https://assets.gqindia.com/photos/63f59ea391ca0ba3444a6c3f/1:1/w_1600%2Cc_limit/1247338339",
                        ),
                        fit: BoxFit.fill),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 15, top: 208.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Givenchy",
                        style: TextStyle(
                            fontSize: 48,
                            color: Colors.white,
                            fontWeight: FontWeight.w900),
                      ),
                      const Text(
                        "The Latest Drop",
                        style: TextStyle(fontSize: 28, color: Colors.white),
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 102.0),
                        child: GestureDetector(
                          onTap: () async {
                         FirebaseServices().facbooklogout();
                          },
                          child: Container(
                            height: 40,
                            width: 170,
                            color: Colors.white,
                            child: const Center(
                                child: Text(
                              "SHOP NOW",
                              style: TextStyle(
                                  fontSize: 17, fontWeight: FontWeight.w900),
                            )),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Expanded(
                child: GridView.builder(
                  shrinkWrap: true,
                  itemBuilder: (Context, index) {
                    return SingleChildScrollView(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: Column(
                          children: [
                            Container(
                              height: 208,
                              decoration: BoxDecoration(color: Colors.red),
                            ),
                            SizedBox(height: 8,),
                            Text(
                              "OUR LEGACY",
                              style: TextStyle(fontSize: 15,fontWeight: FontWeight.w700),
                            ),
                            Text("Find your shoes",style: TextStyle(fontSize: 13,color: Colors.grey),)
                          ],
                        ),
                      ),
                    );
                  },
                  itemCount: 4,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 19,
                      mainAxisSpacing: 29,
                      childAspectRatio: 0.80),
                ))
          ],
        ),
      ),
    );
  }
}
