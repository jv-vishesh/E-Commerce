import 'package:ecommerceapp/Firebase%20Services/firebaseservices.dart';
import 'package:ecommerceapp/add_products_page.dart';
import 'package:ecommerceapp/home_page.dart';
import 'package:ecommerceapp/log_in_page.dart';
import 'package:flutter/material.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key}) : super(key: key);

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  @override
  Widget build(BuildContext context) {
    TextEditingController nameController=TextEditingController();
    TextEditingController passwordController=TextEditingController();
    TextEditingController emailController=TextEditingController();
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.only(left: 16, top: 99),
              child: const Text(
                "Sign In",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 34,
                    fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(
              height: 63,
            ),
            Form(
                child: Padding(
                  padding: const EdgeInsets.only(left: 16.0,right: 16),
                  child: Column(
              children: [
                  TextFormField(
                    controller: nameController,
                    decoration: const InputDecoration(
                        filled: true,
                        fillColor: Color(0x00f2f2f2),
                        label: Text(
                          "Name",
                          style: TextStyle(fontSize: 11),
                        ),
                        border: OutlineInputBorder()),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  TextFormField(
                    controller: emailController,
                    decoration: const InputDecoration(
                        filled: true,
                        fillColor: Color(0x00f2f2f2),
                        label: Text(
                          "Email",
                          style: TextStyle(fontSize: 11),
                        ),
                        border: OutlineInputBorder()),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  TextFormField(
                    controller: passwordController,
                    decoration: const InputDecoration(
                        filled: true,
                        fillColor: Color(0x00f2f2f2),
                        label: Text(
                          "Password",
                          style: TextStyle(fontSize: 11),
                        ),
                        border: OutlineInputBorder()),
                  ),
              ],
            ),
                )),
            const SizedBox(
              height: 8,
            ),
            Container(
              margin: const EdgeInsets.only(right: 20),
              child:  GestureDetector(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>logInPage()));
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    const Text(
                      "Already have an account?",
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                    ),
                    const SizedBox(width: 8),
                    Icon(
                      Icons.arrow_right_alt,color:Colors.yellow[800],
                    )
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 37,
            ),
            Center(
              child: GestureDetector(
                onTap: () async {
                //  await FirebaseServices().emailAndPasswordSignIn(emailController.text, passwordController.text, nameController.text);
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>AddProductsPage()));
                },
                child: Container(
                  margin: const EdgeInsets.only(left: 16, right: 16),
                  height: 40,
                  color: Colors.yellow[800],
                  child: const Center(
                      child: Text(
                    "SIGN UP",
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: Colors.white),
                  )),
                ),
              ),
            ),
            const SizedBox(
              height: 125,
            ),
            const Center(
                child: Text(
              "Or sign up with social account",
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            )),
            const SizedBox(
              height: 12,
            ),
            Row(mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: () async {
                 //await  FirebaseServices().googleSignIn();
                 Navigator.push(context, MaterialPageRoute(builder: (context)=>HomePage()));


                  },
                  child: Container(
                    width: 92,
                    height: 64,
                    decoration: BoxDecoration(
                        color: Colors.white60,
                        borderRadius: BorderRadius.circular(24)),
                    child: const Icon(Icons.g_mobiledata),
                  ),
                ),
                const SizedBox(
                  width: 16,
                ),
                GestureDetector(
                  onTap: (){
                    FirebaseServices().facebooklogin();
                  },
                  child: Container(
                    width: 92,
                    height: 64,
                    decoration: BoxDecoration(
                        color: Colors.white60,
                        borderRadius: BorderRadius.circular(24)),
                    child: const Icon(Icons.facebook),
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
