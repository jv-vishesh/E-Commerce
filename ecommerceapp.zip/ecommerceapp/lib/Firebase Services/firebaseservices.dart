import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class FirebaseServices {
  AccessToken? _accessToken;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _user = FirebaseFirestore.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();


   emailAndPasswordSignIn(
      String emails, dynamic passwords, String names) async {
    await _auth.createUserWithEmailAndPassword(
        email: emails, password: passwords);
    await _user
        .collection("User")
        .doc()
        .set({"name": names, "email": emails, "password": passwords});
  }

   googleSignIn() async {
    try {
      final GoogleSignInAccount? googleSignInAccount =
          await _googleSignIn.signIn();
      if (googleSignInAccount != null) {
        final GoogleSignInAuthentication googleSignInAuthentication =
            await googleSignInAccount.authentication;
        final AuthCredential authCredential = GoogleAuthProvider.credential(
            idToken: googleSignInAuthentication.idToken,
            accessToken: googleSignInAuthentication.accessToken);
        _auth.signInWithCredential(authCredential);
      }else{
        return null;
      }
    } on FirebaseAuthException catch (e) {
      throw e;
    }
  }

  googleSignOut() {
    _googleSignIn.signOut();
  }

  Future<void> facebooklogin() async {
    final LoginResult result = await FacebookAuth.instance.login();

    if (result.status == LoginStatus.success) {
      _accessToken = result.accessToken;
    // final userData = await FacebookAuth.instance.getUserData();
    } else {
      print(result.status);
      print(result.message);
    }
  }
  facbooklogout() async {
    await FacebookAuth.instance.logOut();
    _accessToken = null;
  }

}
