import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';

class Addproduct{
  FirebaseFirestore _firestore=FirebaseFirestore.instance;
  addproducts({String? Productname,Brandname,Size}) async {
    await _firestore.collection("ProductCategory").doc().set({
      "ProductName":Productname,
      "Brand": Brandname,
      "Size": Size,
    }).catchError((e) => print(e));
  }
  XFile? pikedFile;

  getImage() async {
    try {

      }
    catch(e){
      return e;
    }
  }


}