import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ecommerceapp/Firebase%20Services/add_product_in_firebase.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class AddProductsPage extends StatefulWidget {
  const AddProductsPage({super.key});

  @override
  State<AddProductsPage> createState() => _AddProductsPageState();
}

class _AddProductsPageState extends State<AddProductsPage> {
  FirebaseFirestore _auth = FirebaseFirestore.instance;
  var image = "";
  Widget build(BuildContext context) {
    TextEditingController productNameController = TextEditingController();
    TextEditingController brandController = TextEditingController();
    TextEditingController sizeController = TextEditingController();
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
              padding: const EdgeInsets.only(top: 99, left: 8),
              child: const Text(
                "Add Product",
                style: TextStyle(fontSize: 34, fontWeight: FontWeight.w700),
              )),
          const SizedBox(
            height: 63,
          ),
          Form(
              child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              children: [
                TextFormField(
                  controller: productNameController,
                  decoration: const InputDecoration(
                      label: Text(
                        'Product Name',
                        style: TextStyle(fontSize: 11),
                      ),
                      border: OutlineInputBorder()),
                ),
                const SizedBox(
                  height: 9,
                ),
                TextFormField(
                  controller: brandController,
                  decoration: const InputDecoration(
                      label: Text(
                        "Brand",
                        style: TextStyle(fontSize: 11),
                      ),
                      border: OutlineInputBorder()),
                ),
                const SizedBox(
                  height: 9,
                ),
                TextFormField(
                  controller: sizeController,
                  decoration: const InputDecoration(
                      label: Text(
                        "Size",
                        style: TextStyle(fontSize: 11),
                      ),
                      border: OutlineInputBorder()),
                ),
                const SizedBox(
                  height: 58,
                ),
                GestureDetector(
                  onTap: () async {},
                  child: Center(
                    child: Container(
                      height: 126,
                      width: 158,
                      decoration: BoxDecoration(color: Colors.grey[100],),
                      child: const Icon(
                        Icons.image_outlined,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                )
              ],
            ),
          )),
          const SizedBox(
            height: 65,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: GestureDetector(
              onTap: () async {
                await Addproduct().addproducts(Productname: productNameController.text,Brandname: brandController.text,Size: sizeController.text);
              },
              child: Container(
                height: 40,
                color: Colors.yellow[800],
                child: const Center(
                    child: Text(
                  "Add",
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Colors.white),
                )),
              ),
            ),
          )
        ],
      ),
    );
  }
}
