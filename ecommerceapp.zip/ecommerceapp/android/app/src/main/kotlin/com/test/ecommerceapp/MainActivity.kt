package com.test.ecommerceapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
